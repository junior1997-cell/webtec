# Changelog moved!

You can find the releases history with the relative changes visiting the dedicated GitHub page:

https://github.com/FezVrasta/popper.js/releases
